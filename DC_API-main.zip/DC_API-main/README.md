# DC_API
## Installer projet
make install
## Démarrer docker
make up
## Stoper docker
make down
## Démarrer serveur local symfony
make sf serve

## Installation make si commande non trouvé
https://linuxhint.com/run-makefile-windows/

